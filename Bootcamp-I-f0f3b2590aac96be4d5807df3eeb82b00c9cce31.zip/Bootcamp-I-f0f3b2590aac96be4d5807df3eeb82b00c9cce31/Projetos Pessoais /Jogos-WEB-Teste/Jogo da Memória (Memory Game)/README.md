# Jogo da Memória 🧠

Um jogo clássico da memória onde o objetivo é encontrar todos os pares de cartas iguais.

## 🔧 Tecnologias
- HTML
- CSS
- JavaScript

## 🎮 Como jogar
1. Clique nas cartas para revelá-las.
2. Encontre os pares iguais.
3. O jogo termina quando todos os pares forem encontrados.

## 📦 Como executar
Abra o arquivo `index.html` em seu navegador.

