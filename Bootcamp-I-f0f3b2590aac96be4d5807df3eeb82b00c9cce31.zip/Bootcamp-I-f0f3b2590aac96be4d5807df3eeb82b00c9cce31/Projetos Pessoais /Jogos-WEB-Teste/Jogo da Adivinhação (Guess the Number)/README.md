# Jogo da Adivinhação 🎯

Um jogo simples onde o jogador tenta adivinhar um número aleatório entre 1 e 100.

## 🔧 Tecnologias
- HTML
- CSS
- JavaScript

## 🎮 Como jogar
1. O jogo escolhe um número aleatório entre 1 e 100.
2. O jogador insere um palpite.
3. O jogo informa se o número é maior ou menor até o acerto.

## 📦 Como executar
Abra o arquivo `index.html` em seu navegador.

