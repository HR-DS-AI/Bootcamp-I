# Pedra, Papel e Tesoura ✊✋✌️

Um jogo clássico onde você desafia o computador em uma partida de Pedra, Papel ou Tesoura.

## 🔧 Tecnologias
- HTML
- CSS
- JavaScript

## 🎮 Como jogar
1. Escolha entre Pedra, Papel ou Tesoura.
2. O computador faz uma escolha aleatória.
3. O resultado da partida é exibido na tela.

## 📦 Como executar
Abra o arquivo `index.html` em seu navegador.
