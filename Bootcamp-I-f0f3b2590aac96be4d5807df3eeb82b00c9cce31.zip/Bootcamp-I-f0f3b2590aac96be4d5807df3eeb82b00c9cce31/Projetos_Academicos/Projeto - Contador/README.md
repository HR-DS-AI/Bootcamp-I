Projeto - Contador
Descrição
Este é um projeto simples de uma página web que implementa um contador interativo. A página permite incrementar e decrementar um valor exibido na tela usando botões, utilizando HTML, CSS e JavaScript.
Funcionalidades

Exibe um contador inicializado em 0.
Botão "Incrementar" para aumentar o valor do contador.
Botão "Decrementar" para diminuir o valor do contador (não permite valores negativos).
Estilização básica com CSS para uma interface centrada e amigável.

Tecnologias Utilizadas

HTML: Estrutura da página.
CSS: Estilização e layout.
JavaScript: Lógica para incrementar e decrementar o contador.

Projeto Referente do Projeto de Bootcamp I

2. Criação eVersionamentodeProjetos:
 ● Criar um projeto inicial (um pequeno programa, script ou página web) e realizar o
 versionamento do código utilizando Git;
 ● Cometeralteraçõessignificativas e enviar para o repositório no GitHub.
