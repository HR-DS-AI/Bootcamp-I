let contador = 0;
function incrementar() {
    contador++;
    document.getElementById("contador").innerText = contador;
}
