# Bootcamp-I
📂 Contém projetos acadêmicos, pessoais, colaborações via pull requests e documentação técnica. ( como requisitado na tarefa da discplina em questão )
